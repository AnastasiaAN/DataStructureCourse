/***************************************************
# Project: Homework 5.1
# File: hw5_1_5142609052.cpp
# Author: Shen Xiaozhou
# Student ID: 5142609052
# Date: 3/28/2016
***************************************************/

#include "hw5_1_5142609052.h"
#include <iostream>
#include <vector>
#include <string>
#include <utility>
#include <algorithm>
using namespace std;

namespace HW5_1_5142609052 {

    void Name_pairs::read_names() {
        while (true) {
            string namei;
            cin >> namei;
            name.push_back(namei);
            // clear white space and break when meet a '\n'
            char c;
            do {
                c = cin.get();
            } while (c == ' ');
            if (c == '\n') {
                break;
            }
            else {
                cin.putback(c);
            }
        }
    }

    void Name_pairs::read_ages() {
        for (int i = 0; i < name.size(); i++) {
            cout << "Input the age of " << name[i] << ": ";
            int agei;
            cin >> agei;
            age.push_back(agei);
        }
    }

    void Name_pairs::print() const {
        for (int i = 0; i < name.size(); i++) {
            cout << name[i] << " (" << age[i] << ")" << endl;
        }
    }

    // name-age-pair
    typedef pair<string, double> napair;
    // compare function for sort of name-age-pairs
    static bool comp(napair a, napair b) {
        return a.first < b.first; // a.name < b.name
    }

    void Name_pairs::sort() {
        // pack name and age to a name-age-pair
        vector<napair> list;
        for (int i = 0; i < name.size(); i++) {
            list.push_back(napair(name[i], age[i]));
        }
        // sort the vector of pair
        std::sort(list.begin(), list.end(), comp);
        // rebuild two vectors
        name.clear();
        age.clear();
        for (int i = 0; i < list.size(); i++) {
            name.push_back(list[i].first);
            age.push_back(list[i].second);
        }
    }

    ostream &operator << (ostream &out, Name_pairs &np) {
        for (int i = 0; i < np.name.size(); i++) {
            out << np.name[i] << " (" << np.age[i] << ")" << endl;
        }
        return out;
    }
    
    // notice: arguments are not references
    bool operator == (Name_pairs np1, Name_pairs np2) {
        np1.sort();
        np2.sort();
        if (np1.name.size() != np2.name.size()) {
            return false;
        }
        for (int i = 0; i < np1.name.size(); i++) {
            if (np1.name[i] != np2.name[i]) {
                return false;
            }
            if (np1.age[i] != np2.age[i]) {
                return false;
            }
        }
        return true;
    }

    bool operator != (Name_pairs np1, Name_pairs np2) {
        return !(np1 == np2);
    }

}
