/***************************************************
# Project: Homework 5.1
# File: hw5_1_5142609052.h
# Author: Shen Xiaozhou
# Student ID: 5142609052
# Date: 3/28/2016
***************************************************/

#ifndef HW5_1_5142609052_H
#define HW5_1_5142609052_H

#include <iostream>
#include <vector>
#include <string>

namespace HW5_1_5142609052 {

    class Name_pairs {
    private:
        std::vector<std::string> name;
        std::vector<double> age;

    public:
        // read name list from cin
        void read_names();
        // read ages for each name
        void read_ages();
        // print pairs of name and age
        void print() const;
        // sort the list in order of name
        void sort();

    public:
        // print function, version of <<
        friend std::ostream &operator << (std::ostream &out, Name_pairs &np);
        // compare two Name_pairs which are regarded as sets of (name, age)
        friend bool operator == (Name_pairs np1, Name_pairs np2);
        friend bool operator != (Name_pairs np1, Name_pairs np2);
    };

}

#endif
