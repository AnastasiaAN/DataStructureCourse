/***************************************************
# Project: Homework 5.2
# File: hw5_2_5142609052.cpp
# Author: Shen Xiaozhou
# Student ID: 5142609052
# Date: 3/28/2016
***************************************************/

#include <iostream>
#include <cmath>
#include <vector>
#include <typeinfo>
using namespace std;

class Shape {
public:
    virtual double getArea() const = 0;
};

class TwoDimensionalShape : public Shape{
    
};

class ThreeDimensionalShape : public Shape {
public:
    virtual double getVolume() const = 0;
};

class Circle : public TwoDimensionalShape {
private:
    double r;
public:
    Circle(double radius);
    double getArea() const;
};

Circle::Circle(double radius) : r(radius) {
    
}

double Circle::getArea() const {
    // area = pi*r^2
    return M_PI * r * r;
}

class Square : public TwoDimensionalShape {
private:
    double a;
public:
    Square(double edge_length);
    double getArea() const;
};

Square::Square(double edge_length) : a(edge_length) {
    
}

double Square::getArea() const {
    // area = a^2
    return a * a;
}

class Ball : public ThreeDimensionalShape {
private:
    double r;
public:
    Ball(double radius);
    double getArea() const;
    double getVolume() const;
};

Ball::Ball(double radius) : r(radius) {
    
}

double Ball::getArea() const {
    // area = 4*pi*r^2
    return 4 * M_PI * r * r;
}

double Ball::getVolume() const {
    // volume = 4/3*pi*r^3
    return 4 * M_PI *r * r * r / 3;
}

class Cylinder : public ThreeDimensionalShape {
private:
    double r, h;
public:
    Cylinder(double radius, double height);
    double getArea() const;
    double getVolume() const;
};

Cylinder::Cylinder (double radius, double height) : r(radius), h(height) {
    
}

double Cylinder::getArea() const {
    // area = 2*pi*r^2+2*pi*r*h
    return 2 * M_PI * r * r + 2 * M_PI * r * h;
}

double Cylinder::getVolume() const {
    // volume = pi*r^2*h
    return M_PI * r * r * h;
}

// test function
int main() {
    Circle circle(3);
    Square square(4);
    Ball ball(5);
    Cylinder cylinder(6, 7);
    
    // Polymorphism
    vector<Shape *> shapes;
    shapes.push_back(&circle);
    shapes.push_back(&square);
    shapes.push_back(&ball);
    shapes.push_back(&cylinder);
    
    typedef ThreeDimensionalShape TDShape;
    // test methods of each class
    for (vector<Shape *>::iterator i = shapes.begin(); i != shapes.end(); ++i) {
        Shape *shape = *i;
        
        cout << typeid(*shape).name() << endl;
        
        // both 2D and 3D shape have area, so print it
        cout << "Its area is " << shape->getArea() << endl;
        
        TDShape *tdshape = dynamic_cast<TDShape *>(shape);
        // if the shape is 3D shape then print its volume
        if (tdshape) {
            cout << "Its volume is " << tdshape->getVolume() << endl;
        }
    }
    
    return 0;
}
