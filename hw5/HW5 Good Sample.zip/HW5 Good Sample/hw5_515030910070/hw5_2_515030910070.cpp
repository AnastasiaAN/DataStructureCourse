//homework5 question 2

#include <iostream>
#include <vector>
#include <string>

using namespace std;
const double pi = 3.1415926;										//Constant ��;

class Shape {														//Basical class;
public:
	virtual void print() = 0;											//Declear pure virtual function:print();
};
class TwoDimensionalShape :public Shape {							//Second basical class TwoDimensionalShape;
public:
	virtual double getArea() = 0;										//Declear pure virtual function:getArea();
	void print();
};
class ThreeDimensionalShape :public Shape {							//Second basical class ThereDimensionalShape;
public:
	virtual double getArea() = 0;										//Declear pure virtual function:getArea();
	virtual double getVolume() = 0;									//Declear pure virtual function:getVolume();
	virtual void print();
};
class Circle :public TwoDimensionalShape {
public:
	double getArea();												//Declear function:getArea();
	Circle(double r);												//Constructor of Circle;
private:
	double r;														//The radius of the circle;
};
Circle::Circle(double R)
	:r(R) {}
class Square :public TwoDimensionalShape {
public:
	double getArea();
	Square(double a);
private:
	double a;														//The length of edge of the square;
};
Square::Square(double A)
	:a(A) {}
class Ball :public ThreeDimensionalShape {
public:
	double getArea();
	double getVolume();												//Declear function:getVolume();
	Ball(double r);
private:
	double r;														//The radius of the ball;
};
Ball::Ball(double R)
	:r(R) {}

class Cylinder :public ThreeDimensionalShape {
public:
	double getArea();
	double getVolume();
	Cylinder(double r, double h);
private:
	double r;														//The radius of the cylinder;
	double h;														//The height of the cylinder;
};
Cylinder::Cylinder(double R, double H)
	:r(R), h(H) {}
void TwoDimensionalShape::print() {									//Definite function:print();
	cout << "The area is:" << getArea() << endl;
	cout << endl;
}
void ThreeDimensionalShape::print() {
	cout << "The area is:" << getArea() << endl;
	cout << "The volume is:" << getVolume() << endl;
	cout << endl;
}
double Circle::getArea() {
	return pi*r*r;													//The area of the shape;
}
double Square::getArea() {
	return a*a;
}
double Ball::getArea() {
	return 4 * pi*r*r;
}
double Cylinder::getArea() {
	return 2 * pi*r*h + 2 * pi*r*r;
}
double Ball::getVolume() {											//The volume of the shape;
	return pi*r*r*r * 4 / 3;
}
double Cylinder::getVolume() {
	return pi*r*r*h;
}

int main() {
	vector<Shape*>shapes;											//Creat a vector of the pointers;
	Circle circle(5.0);												//Creat a Shape called circle which radius is 5;
	Square square(5.0);
	Ball ball(5.0);
	Cylinder cylinder(5.0, 5.0);
	Shape *a = &circle;												//Creat a pointer of circle;
	Shape *b = &square;
	Shape *c = &ball;
	Shape *d = &cylinder;
	shapes.push_back(a);											//Put the pointer a into the vector shapes;
	shapes.push_back(b);
	shapes.push_back(c);
	shapes.push_back(d);
	for (int i = 0; i < shapes.size(); i++)shapes[i]->print();		//Print the informaiton of the shapes;
}
