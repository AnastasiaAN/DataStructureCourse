//homework 5
#include <iostream>
#include<vector>
#include<string>


using namespace std;

class Name_pairs {
public:
	void read_names();										//Get a list of names;
	void read_ages();										//Get the age of the names;
	void print();											//Print the names and age like:(Tom,23);
	void sort();											//Make the name into an correct order;
	bool operator==(Name_pairs another);							//Redefinite the operator"==";
	bool operator!=(Name_pairs another);							//Redefinite the operator"!=";

private:
	vector<string>name;										//List of the names you get;
	vector<double>age;										//List of the age you get;
	int judge_order(string first, string second);			//A function to judge which word is before another one;
};

void Name_pairs::read_names() {
	int start = 0;
	string input_words;											//The inputed string of names;
	string put_name;
	cout << "please enter names(like:'Tom,Mike...'):" << endl;
	cin >> input_words;
	for (int i = 0; i < input_words.length(); i++) {
		if (input_words[i] == ',') {
			put_name = input_words.substr(start, i - start);
			start = i + 1;
			name.push_back(put_name);
		}
		else if (i == input_words.length() - 1) {
			put_name = input_words.substr(start, i + 1 - start);
			name.push_back(put_name);
		}
	}
	return;
}
void Name_pairs::read_ages() {
	double input_age;											//The inputed string of age;
	for (int i = 0; i < name.size(); i++) {
		cout << "please enter age of " << name[i] << ":" << endl;
		cin >> input_age;
		age.push_back(input_age);
	}

}
void Name_pairs::print() {
	for (int i = 0; i < name.size(); i++) {
		cout << "(" << name[i] << "," << age[i] << ")" << endl;
	}

}
int Name_pairs::judge_order(string first, string second) {
	if (first.size() < second.size()) {
		for (int i = 0; i < first.size(); i++) {
			if (first[i] < second[i])return 1;
			else if (first[i]>second[i])return 0;
		}
		return 1;											//First one is before the second one;
	}
	else if (first.size() > second.size()) {
		for (int i = 0; i < second.size(); i++) {
			if (first[i] < second[i])return 1;
			else if (first[i]>second[i])return 0;
		}
		return 0;											//Second one is before the first one;
	}
	else {
		for (int i = 0; i < second.size(); i++) {
			if (first[i] < second[i])return 1;
			else if (first[i]>second[i])return 0;
		}
		return 1;											//They have the same name;
	}
}
void Name_pairs::sort()
{
	for (int i = 0; i < name.size() - 1; i++) {
		if (judge_order(name[i], name[i + 1]) == 0) {		//Exchange their position;
			string name1 = name[i];
			double age1 = age[i];
			name[i] = name[i + 1];
			name[i + 1] = name1;
			age[i] = age[i + 1];
			age[i + 1] = age1;
		}
	}
}
ostream&operator <<(ostream&os, Name_pairs pairs) {
	pairs.print();
	return os;
}
bool Name_pairs::operator==(Name_pairs another) {
	int size_a = another.name.size();
	int size_b = name.size();
	if (size_a != size_b)return false;							//Different numbers of names;
	for (int i = 0; i < size_a; i++) {
		for (int j = 0; j < size_b; j++) {
			if (name[i] == another.name[j] && age[i] != another.age[j])return false;	//Same name but different age;
			if (j == size_b&&name[i] != another.name[i])return false;				//There is no same name with name[j];
			if (name[i] == another.name[j] && age[i] == age[j]) break;			//Same information;

		}
	}
	return true;
}
bool Name_pairs::operator!=(Name_pairs another) {
	int size_a = another.name.size();
	int size_b = name.size();
	if (size_a != size_b)return true;							//Different numbers of names;
	for (int i = 0; i < size_a; i++) {
		for (int j = 0; j < size_b; j++) {
			if (name[i] == another.name[j] && age[i] != another.age[j])return true;		//Same name but different age;
			if (j == size_b&&name[i] != another.name[i])return true;				//There is no same name with name[j];
			if (name[i] == another.name[j] && age[i] == age[j]) break;			//Same information;

		}
	}
	return false;
}
