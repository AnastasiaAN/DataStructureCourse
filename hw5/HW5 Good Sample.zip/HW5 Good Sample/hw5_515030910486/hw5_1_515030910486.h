
//
// This header file implements a Name_pairs class
// F1503020 515030910486
//

#include <iostream>
#include "std_lib_facilities.h"
using namespace std;

//-------- declarations --------

class Name_pairs{
public:
	void read_names();		// read names until nothing is inputed (press ENTER)
	void read_ages();		// let the user input an age for each of the name in vector<string> name
							// and store them in vector<int> age
	void print();			
	void sort();			// sort the name vector according to the alphabet order
							// change the order of the age vector along
							// if there are same names, sort them according to the ages
							
	friend ostream& operator<<(ostream& output, Name_pairs& np);	// print all the (name[i],age[i]) pairs
																	// print one pair on each line
	friend bool operator==(Name_pairs& left, Name_pairs& right);	// compare all names & ages
	friend bool operator!=(Name_pairs& left, Name_pairs& right);	// compare all names & ages
	
	int get_name_count();
	int get_age_count();

private:
	vector<string> name;
	vector<double> age;
	void check_match();		// check if name_count == age_count
};


//-------- definitions --------

// read names until nothing is inputed (press ENTER)
void Name_pairs::read_names(){
	bool if_first_time = true;
	cout << "Input names: " << endl;
	
	char chr;					// avoid getline() problem
	chr = cin.get();
	if(chr == '\n'){
		cin.putback(chr);
		cin.ignore();
	}
	else
		cin.putback(chr);
	
	string name_str;
	while(getline(cin, name_str)){
		//cout << "entering..." << endl;
		if(name_str == "") break;
		name.push_back(name_str);
		//cout << "Logged: " << name_str << endl;
	}
}

int Name_pairs::get_name_count(){
	return name.size();
}

int Name_pairs::get_age_count(){
	return age.size();
}

// let the user input an age for each of the name in vector<string> name
// and store then in vector<int> age
void Name_pairs::read_ages(){
	if (get_name_count() == 0)	return;
	for(vector<string>::iterator it = name.begin(); it != name.end(); ++it){
		cout << "Input the age of " << *it << ": ";
		int age_int;
		cin >> age_int;
		age.push_back(age_int);
	}
}

// check if name_count matches with age_count
void Name_pairs::check_match(){
	if(get_name_count() != get_age_count())
		error("age count does not match with name count");
}

// print all the (name[i],age[i]) pairs
// print one pair on each line
void Name_pairs::print(){
	check_match();
	for(int i = 0; i < get_name_count(); ++i)
		cout << name[i] << "\t" << age[i] << endl;
}

// sort the name vector according to the alphabet order
// change the order of the age vector along
// if there are same names, sort them according to the ages
void Name_pairs::sort(){
	check_match();
	int name_count = get_name_count();
	if(name_count == 0) return;
	// sort the name vector according to the alphabet order
	for(int i = 0; i < name_count - 1; ++i){
		for(int j = 0; j < name_count - i - 1; ++j){
			if (name[j+1] < name[j]){
				string temp_name;
				int temp_age;
				
				temp_name = name[j];
				name[j] = name[j+1];
				name[j+1] = temp_name;
				
				temp_age = age[j];
				age[j] = age[j+1];
				age[j+1] = temp_age;
				
			}
			// if there are same names, sort them according to the ages
			else if (name[j+1] == name[j]){
				if (age[j+1] < age[j]){
					int temp_age;
					temp_age = age[j];
					age[j] = age[j+1];
					age[j+1] = temp_age;
				}
			}
		}
	}
}

ostream& operator<<(ostream& output, Name_pairs& np){
	np.check_match();
	for(int i = 0; i < np.get_name_count(); ++i)
		output << np.name[i] << "\t" << np.age[i] << endl;
	return output;
}

bool operator==(Name_pairs& left, Name_pairs& right){
	left.check_match();		// check both Name_pairs's status then sort them
	left.sort();
	right.check_match();
	right.sort();
	int left_count = left.get_name_count();
	int right_count = right.get_name_count();
	if(left_count != right_count)
		return false;
	if(left_count == 0)
		return true;
		
	for(int i = 0; i < left_count; ++i){
		if((left.name[i] != right.name[i])||(left.age[i] != right.age[i]))
			return false;
	}
	return true;
}

bool operator!=(Name_pairs& left, Name_pairs& right){
	left.check_match();		// check both Name_pairs's status then sort them
	left.sort();
	right.check_match();
	right.sort();
	int left_count = left.get_name_count();
	int right_count = right.get_name_count();
	if(left_count != right_count)
		return true;
	if(left_count == 0)
		return false;
		
	for(int i = 0; i < left_count; ++i){
		if((left.name[i] != right.name[i])||(left.age[i] != right.age[i]))
			return true;
	}
	return false;
}


/*
int main(int argc, char *argv[]) {
	Name_pairs np1, np2;
	np1.read_names();
	np1.read_ages();
	
	cout << endl;
	
	np2.read_names();
	np2.read_ages();
	

	
	if (np1 != np2)
		cout << "np1 not equal np2" << endl;
	else {
		cout << "np1 equal np2" << endl;
	}
	
	return 0;
}
*/