#include <iostream>
#include "std_lib_facilities.h"
#include <cmath>
const string INPUT = "> ";		// use to indicate waiting for input
const string OUTPUT = "$ ";		// use to indicate this line is printed by computer
using namespace std;


class Shape{
/*OVERVIEW: an abstract base class for all shapes
			a shape can be printed
*/
public:
	virtual void print() = 0;	// all shapes can be printed
};

class TwoDimentionalShape:public Shape{
/*OVERVIEW: an abstract base class for all 2D shapes
			a 2D shape must have an area
*/
public:
	void print();		//declare print() for 2D shapes here to implement it
	virtual double getArea() = 0;	// all 2D shapes have an area
};

class ThreeDimentionalShape:public TwoDimentionalShape{
/*OVERVIEW: an abstract base class for all 3D shapes.
			Besides an area(surface area),
			a 3D shape also has a volume.
*/
public:
	void print();		//declare print() for 3D shapes here to implement it
	virtual double getVolume() = 0;	// all 3D shapes have a volume
};


class Circle:public TwoDimentionalShape{
/*OVERVIEW: an class for circles which have a radius r
*/
public:
	Circle(double radius): r(radius){}		// a constructor for Circle
	virtual double getArea();				// getArea() may be overwritten
	void setRadius(double radius){r = radius;};			// set radius
private:
	double r;								
	
};


class Square:public TwoDimentionalShape{
/*OVERVIEW: an class for squares which have a side length a
*/
public:
	Square(double side_length): a(side_length){} // a constructor for Square
	virtual double getArea();                    // getArea() may be overwritten
	void setSideLength(double sideLength){a = sideLength;};  // set side length
private:
	double a;
	
};

class Ball:public ThreeDimentionalShape{
public:
	Ball(double radius): r(radius){}		// a constructor for Ball
	double getArea();						// getArea() cannot be overwritten
	double getVolume();						// calculate the volume of the ball
	void setRadius(double radius){r = radius;};			// set radius

private:
	double r;
	
};

class Cylinder:public ThreeDimentionalShape{
public:
	Cylinder(double radius, double height): r(radius), h(height){}	
	// a constructor for Cylinder
	double getArea();						// getArea() cannot be overwritten
	double getVolume();						// calculate the volume of the ball
	void setRadius(double radius){r = radius;};			// set radius
	void setHeight(double height){h = height;};			// set height

private:
	double r,h;

};

void TwoDimentionalShape::print(){
	cout << "area = " << "\t" << getArea() << endl;
}

void ThreeDimentionalShape::print(){
	cout << "area = " << "\t" << getArea() << "\t"
		 << "volume = " << "\t" << getVolume() << endl;
}

double Circle::getArea(){
	return M_PI * pow(r, 2);
}

double Square::getArea(){
	return pow(a, 2);
}

double Ball::getArea(){
	return 4 * M_PI * pow(r, 2);
}

double Cylinder::getArea(){
	return 2 * M_PI * pow(r, 2) + 2 * M_PI * r * h;
}

double Ball::getVolume(){
	return 4.0 / 3.0 * M_PI * pow(r, 3);
}

double Cylinder::getVolume(){
	return M_PI * pow(r, 2) * h;
}

// print hint for shape number shape_num:
void print_hint(int shape_num){
	cout << OUTPUT << "Please input shape name for shape NO." << shape_num
		 << " ('q' to stop): " << endl;
	cout << OUTPUT << "(Circle/Square/Ball/Cylinder)" << endl;
	cout << INPUT;
}

int main(int argc, char *argv[]) {
	vector<Shape*> Shapes;		//vector for storing all shapes
	string shape_str;			//string for temporarily storing the shape string
	int shape_num = 1;			//int for counting shapes

	print_hint(shape_num);
	while(cin >> shape_str){
		if(shape_str == "Circle"){
			double r;
			cout << OUTPUT << "Please input the radius of the Circle: " << endl;
			cout << INPUT;
			cin >> r;
			Circle circle(r);
			Shapes.push_back(& circle);
		}
		else if(shape_str == "Square"){
			double a;
			cout << OUTPUT 
				 << "Please input the side length of the Square: " << endl;
			cout << INPUT;
			cin >> a;
			Square square(a);
			Shapes.push_back(& square);
		}
		else if(shape_str == "Ball"){
			double r;
			cout << OUTPUT << "Please input the radius of the Ball: " << endl;
			cout << INPUT;
			cin >> r;
			Ball ball(r);
			Shapes.push_back(& ball);
		}
		else if(shape_str == "Cylinder"){
			double r, h;
			cout << OUTPUT 
				 << "Please input the radius and height of the Cylinder: " << endl;
			cout << INPUT;
			cin >> r >> h;
			Cylinder cylinder(r, h);
			Shapes.push_back(& cylinder);
		}
		else if(shape_str == "q"){
			break;
		}
		else{
			cout << OUTPUT << "Shape name \"" << shape_str << "\" not exist. Try again." 
				 << endl;
		}
		cout << endl;
		++ shape_num;
		print_hint(shape_num);
	}
	
	cout << endl;
	
	//print each shape
	for (int i = 0; i < shape_num - 1; ++i){
		cout << OUTPUT << "Printing Shape NO." << i + 1 << endl;
		cout << OUTPUT;
		Shapes[i] -> print();
	}
	
}