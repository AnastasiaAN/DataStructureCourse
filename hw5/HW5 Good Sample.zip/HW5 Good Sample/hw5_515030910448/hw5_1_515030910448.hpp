//
//  problem1.hpp
//  SilliMe
//
//  Created by Tang Chuzhe on 16/3/29.
//  Copyright © 2016年 Tang Chuzhe. All rights reserved.
//

#ifndef problem1_hpp
#define problem1_hpp

#include <iostream>
#include <string>
#include <vector>
#include <cctype>

/* Class NameAgePairs */
class NameAgePairs {
public:
    NameAgePairs();
    
    // error
    class indexError {};
    class incompatibleLenth {};
    class invalidTerminator {};
    
    // non-modifying functions
    std::string getName(unsigned long index) const;
    double getAge(unsigned long index) const;
    unsigned long getLenth() const;
    bool print() const;
    
    // modifying functions
    void readNames();
    void readAges();
    bool sort();
    
private:
    std::vector<std::string> names;
    std::vector<double> ages;
};

// operator overload
std::ostream &operator<<(std::ostream &os, const NameAgePairs &pair);
bool operator==(const NameAgePairs &pair1, const NameAgePairs &pair2);
bool operator!=(const NameAgePairs &pair1, const NameAgePairs &pair2);



/* constuctors */

NameAgePairs::NameAgePairs()
:names(), ages() {}


/* non-modifying functions */

/*
 * return name at position index
 * throw indexError when index out of range
 */
std::string NameAgePairs::getName(unsigned long index) const {
    if (index >= names.size()) {
        throw indexError();
    }
    
    return names[index];
}

/*
 * return age at position index
 * throw indexError when index out of range
 */
double NameAgePairs::getAge(unsigned long index) const {
    if (index >= ages.size()) {
        throw indexError();
    }
    
    return ages[index];
}

/*
 * return the lenth of this NameAgePairs
 * throw incompatibleLenth when lenth of ages and names are different
 */
unsigned long NameAgePairs::getLenth() const {
    if (names.size() != ages.size()) {
        throw incompatibleLenth();
    } else {
        return names.size();
    }
}

/*
 * print (name, age) pairs to std::cin
 * each pair ends with a '\n'
 */
bool NameAgePairs::print() const {
    unsigned long lenth;
    try {
        lenth = getLenth();
    } catch (incompatibleLenth) {
        return false;
    }
    
    for (unsigned long i = 0; i < lenth; ++i) {
        std::cout << '(' << getName(i) << ", " << getAge(i) << ")\n";
    }
    
    return true;
}


/* modifying functions */

/*
 * read names from std::cin
 * stop when recieve a stop signal("quit")
 */
void NameAgePairs::readNames() {
    const std::string stop = "stop";
    
    std::cout << "names please. type \"stop\" to stop:" << std::endl;
    std::cin.clear();
    std::string name;
    while (std::cin >> name && name != stop) {
        name[0] = toupper(name[0]);
        names.push_back(name);
    }
}

/*
 * read ages from std::cin
 * stop when recieve a stop signal("quit")s, or number of ages matches that of names
 * throw invalidTerminator when not stoped with stop signal
 */
void NameAgePairs::readAges() {
    const std::string stop = "stop";
    
    std::cout << "ages please. type \"stop\" to stop:" << std::endl;
    std::cin.clear();
    double age;
    for (unsigned long i = ages.size(), n = names.size(); i < n; ++i) {
        std::cout << names[i] << ": ";
        if (!(std::cin >> age)) {
            break;
        }
        ages.push_back(age);
    }
    
    // check if end with stop signal;
    if (std::cin.fail()) {
        std::cin.clear();
        std::string s;
        if (!(std::cin >> s) || s != stop) {
            throw invalidTerminator();
        }
    }
}

/*
 * using quick sort on vector names, and meanwhile modify ages to match new names
 * return true if succeed, else, return false
 */
bool NameAgePairs::sort() {
    // initial partition
    unsigned long lenth;
    try {
        lenth = getLenth();
    } catch (incompatibleLenth) {
        return false;
    }
    
    typedef std::pair<unsigned, unsigned> section;
    
    section initial(0, lenth - 1);
    std::vector<section> partitions(1, initial);
    
    // start sorting
    while (!partitions.empty()) {
        // get a partition to sort
        section partition = partitions.back();
        partitions.pop_back();
        
        // set up a pivot and prepare to sort
        unsigned long pivot = partition.first, current = partition.first + 1;
        // compare every item after pivot in the item to pivot
        for (unsigned long index = partition.first + 1; index <= partition.second; ++index) {
            if (names[index] < names[pivot] || (names[index] == names[pivot] && ages[index] < ages[pivot])) {
                // swap name at index and pivot
                std::string temp_name = names[index];
                names[index] = names[current];
                names[current] = temp_name;
                
                // swap coresponding ages
                double temp_age = ages[index];
                ages[index] = ages[current];
                ages[current] = temp_age;
                
                ++current;
            }
        }
        
        // move pivot (both name and age) to the back of current partition
        std::string temp_name_pivot = names[pivot];
        names[pivot] = names[current - 1];
        names[current - 1] = temp_name_pivot;
        
        double temp_age_pivot = ages[pivot];
        ages[pivot] = ages[current - 1];
        ages[current - 1] = temp_age_pivot;
        
        // add new partions
        if (current - 1 - pivot > 1) { // when lenth of left partition (items smaller than pivot) > 1
            section new_partition(pivot, current - 1);
            partitions.push_back(new_partition);
        }
        if (partition.second - current + 1 > 1) { // when lenth of right partition (items larger than pivot) > 1
            section new_partition(current, partition.second);
            partitions.push_back(new_partition);
        }
    }
    
    return true;
}


/* operator overload */

/*
 * print (name, age) pairs to std::ostream
 * each pair ends with '\n'
 */
std::ostream &operator<<(std::ostream &os, const NameAgePairs &pairs) {
    for (unsigned long i = 0, n = pairs.getLenth(); i < n; ++i) {
        os << '(' << pairs.getName(i) << ", " << pairs.getAge(i) << ")\n";
    }
    
    return os;
}

/*
 * return true if both NamePair include the same names with same ages
 * else, return false
 */
bool operator==(const NameAgePairs &pairs1, const NameAgePairs &pairs2) {
    NameAgePairs new_pairs1 = pairs1, new_pairs2 = pairs2;
    
    // see if they have matching pairs to be compared
    try {
        new_pairs1.sort();
        new_pairs2.sort();
    } catch (NameAgePairs::incompatibleLenth) {
        return false;
    }
    
    // check lenth
    if (new_pairs1.getLenth() != new_pairs2.getLenth()) {
        return false;
    }
    
    // compare one by one
    for (unsigned long i = 0, n = new_pairs1.getLenth(); i < n; ++i) {
        if (new_pairs1.getName(i) != new_pairs2.getName(i) || new_pairs1.getAge(i) != new_pairs2.getAge(i)) {
            return false;
        }
    }
    
    return true;
}

/*
 * return true if both NamePair include different names with same ages
 * else, return false
 */
bool operator!=(const NameAgePairs &pairs1, const NameAgePairs &pairs2) {
    return !(pairs1 == pairs2);
}


#endif /* problem1_hpp */

