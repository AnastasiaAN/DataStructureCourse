#include <iostream>
#include <string>
#include <vector>
#include <cmath>

using namespace std;

const double pi = 3.14159265359;


/* exceptions */
class badParameter {};


/* Class Shape */
class Shape {
public:
    virtual double getArea() const = 0;
    virtual double getVolume() const = 0;
    string getType() const {
        return shape_type;
    }

protected:
    string shape_type;
};

ostream &operator<<(ostream &os, const Shape &shape) {
    double area = shape.getArea(), volume = shape.getVolume();
    
    os << "this is a " << shape.getType() << endl;
    
    if (area >= 0) {
        os << "area is: " << area << endl;
    }
    
    if (volume >= 0) {
        os << "volume is: " << volume << endl;
    }
    
    return os;
}


/* Class TwoDimensionalShape */
class TwoDimensionalShape: public Shape {
public:
    double getVolume() const {
        return -1;
    }
};


/* Class ThreeDimensionalShape */
class ThreeDimensionalShape: public Shape {
};


/* Class Circle */
class Circle: public TwoDimensionalShape {
public:
    Circle(double radius)
    :radius(radius) {
        shape_type = "circle";
        if (radius < 0) {
            throw badParameter();
        }
    }
    
    double getArea() const {
        return pi * pow(radius, 2);
    }
    
private:
    double radius;
};


/* Class Square */
class Square: public TwoDimensionalShape {
public:
    Square(double side_lenth)
    :side_lenth(side_lenth) {
        shape_type = "square";
        if (side_lenth < 0) {
            throw badParameter();
        }
    }
    
    double getArea() const {
        return pow(side_lenth, 2);
    }
    
private:
    double side_lenth;
};


/* Class Ball */
class Ball: public ThreeDimensionalShape {
public:
    Ball(double radius)
    :radius(radius) {
        shape_type = "ball";
        if (radius < 0) {
            throw badParameter();
        }
    }
    
    
    double getArea() const {
        return 4 * pi * pow(radius, 2);
    }
    
    double getVolume() const {
        return pi * 4 / 3 * pow(radius, 3);
    }
    
private:
    double radius;
};


/* Class Cylinder */
class Cylinder: public ThreeDimensionalShape {
public:
    Cylinder(double radius, double height)
    :radius(radius), height(height) {
        shape_type = "cylinder";
        if (radius < 0 || height < 0) {
            throw badParameter();
        }
    }
    
    
    double getArea() const {
        return 2 * pi * pow(radius, 2) + 2 * pi * radius * height;
    }
    
    double getVolume() const {
        return pi * pow(radius, 2) * height;
    }
    
private:
    double radius, height;
};


int main(void) {
    // get some instance
    Circle circle(1);
    Square square(2);
    Ball ball(3);
    Cylinder cylinder(4, 5);
    
    // get them into vector
    vector<Shape*> shapes;
    shapes.push_back(&circle);
    shapes.push_back(&square);
    shapes.push_back(&ball);
    shapes.push_back(&cylinder);
    
    // output infos
    for (unsigned long i = 0, n = shapes.size(); i < n; ++i) {
        cout << *shapes[i];
    }
    
    return 0;
}

