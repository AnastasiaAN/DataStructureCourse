#ifndef HW5_2_515030910241_H_INCLUDED
#define HW5_2_515030910241_H_INCLUDED


/**************************************************************************************
*   This header contains some declarations of classes
*   Shape; TwoDimentionalShape; ThreeDimentionalShape; Circle; Square; Ball; Cylinder
*   Shape class is a base class;others are derived ones
*   Every two-dimentional shapes has a member function:     getArea(); it returns area;
*   Every three-dimentional shapes has both getArea() and getVolume()
*   getArea() returns surface area, getVolume() returns volume
***************************************************************************************/


/*************************************************************************
*   Shape class is used as a inteface,it is an abstract class
**************************************************************************/
class Shape{
    public:
        virtual void getArea()=0;
        virtual void getVolume()=0;
};


/*************************************************************************
*   2D and 3D are direct subclasses of Shape   class 3D is yet an abstract.
**************************************************************************/
class TwoDimentionalShape:public Shape{
    public:
        virtual void getVolume();
};

class ThreeDimentionalShape:public Shape{};


/*************************************************************************
*   Square and Circle are subclasses of 2D
*   Both of them have a member function:getArea and respond differently
**************************************************************************/
class Square:public TwoDimentionalShape{
    public:
        Square(double a):a(a){};
        virtual void getArea();
    private:
        double a;
};

class Circle:public TwoDimentionalShape{
    public:
        Circle(double r):r(r){};
        virtual void getArea();
    private:
            double r;
};

/*************************************************************************
*   Ball and Cylinder are two subclasses of 3D shape
*   They have member function:getArea and getVolume
**************************************************************************/

class Ball:public ThreeDimentionalShape{
    public:
        Ball(double r):r(r){};
        virtual void getArea();
        virtual void getVolume();
    private:
        double r;
};

class Cylinder:public ThreeDimentionalShape{
    public:
        Cylinder(double r,double h):r(r),h(h){};
        virtual void getArea();
        virtual void getVolume();
    private:
        double r;
        double h;
};





























#endif // HW5_2_515030910241_H_INCLUDED
