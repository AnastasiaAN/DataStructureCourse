#include "hw5_1_515030910241.h"
#include <iostream>


/****************************************
*read_names read a line
*names are split with whitespace
*press Enter Key to finish reading
****************************************/

void Name_pairs::read_names(){
/**************************************
*   read string until come across a '\n'
***************************************/
    std::string single_name;
    std::cout <<"input names split with witespace,press ENTER to finish:"<<std::endl;
    while (std::cin>>single_name){
        name.push_back(single_name);
        char next_char;
        std::cin.get(next_char);
        if (next_char=='\n')break;
        std::cin .putback(next_char);
    }
}

void Name_pairs::read_ages(){
/*************************************
*   read ages until come across a '\n'
**************************************/
    double single_age;
    std::cout <<"Please input corresponding age"
              <<"split with witespace press KEY ENTER to finish:"<<std::endl;
    while (std::cin>>single_age){
        age.push_back(single_age);
        char next_char;
        std::cin.get(next_char);
        if (next_char=='\n')break;
        std::cin .putback(next_char);
    }
}
/***************************************
*   sort the lists in lexicographic order
*   using method: Bubble sort
****************************************/
void Name_pairs::sort(){
    for (int i=0;i<int(name.size())-1;i++){
        for (int j=0;j<int(name.size())-i-1;j++){
            if (name[j]>name[j+1]){
                std::string name_temp=name[j];
                name[j]=name[j+1];
                name[j+1]=name_temp;
                double age_temp=age[j];
                age[j]=age[j+1];
                age[j+1]=age_temp;
            }
        }
    }
}

/***************************************************
*   print infomation of namepairs to visualize in the screen
***************************************************/
void Name_pairs::print(){
    for (int i =0;i<int(name.size());i++){
        std::cout <<"("<<name[i]<<","<<age[i]<<")"<<std::endl;
    }
}
//    the same function as print
std::ostream &operator <<(std::ostream&output,Name_pairs&np){
    for (int i=0;i<int(np.name.size());i++)
        output <<"("<<np.name[i]<<","<<np.age[i]<<")"<<std::endl;
    return output;
}
/**********************************************************
*   sort two lists and check one by one to see whether they are not equal
*   if there exists a single pair different, then return true
*   else return false
***********************************************************/
bool operator !=(Name_pairs&np1,Name_pairs&np2){
    if (np1.name.size()!=np2.name.size())return true;
    np1.sort();
    np2.sort();
    for (int i =0;i<int(np1.name.size());i++)
        if ((np1.name[i]!=np2.name[i])||(np1.age[i]!=np2.age[i]))return true;
    return false;
}
/*******************************************************
*   opposite of !=
********************************************************/
bool operator ==(Name_pairs &np1,Name_pairs&np2){
    if(operator!=(np1,np2))return false;
    return true;
}
