#include "hw5_2_515030910241.h"
#include <iostream>

const double pi=3.1415926;
/////////////////////////////////////////////////////////////
//  definition of virtual function getVolume
void TwoDimentionalShape::getVolume(){
    std::cout<<"2D shape's volume   :0";
}


////////////////////////////////////////////////////////////
//definition of member function in Square
void Square::getArea(){
    double squareArea=a*a;
    std::cout<< "square's area      :"<<squareArea;
}

////////////////////////////////////////////////////////////
//definition of member function in Circle
void Circle::getArea(){
    double circleArea=pi*r*r;
    std::cout<<"circle's area       :"<<circleArea;
}

////////////////////////////////////////////////////////////
//definition of member function in Ball
//first is getArea
//Second is getVolume
void Ball::getArea(){
    double ballArea=4.0*pi*r*r;
    std::cout<<"ball's area         :"<<ballArea;
}

void Ball::getVolume(){
    double ballVolume=4.0/3.0*pi*r*r*r;
    std::cout<<"ball's volume       :"<<ballVolume;
}


///////////////////////////////////////////////////////////
//definition of getArea and getVolume
void Cylinder::getArea(){
    double cylinderArea=2.0*pi*r*r+2.0*pi*r*h;
    std::cout<<"cylinder's area     :"<<cylinderArea;
}

void Cylinder::getVolume(){
    double cylinderVolume=pi*r*r*h;
    std::cout<<"cylinder's volume   :"<<cylinderVolume;
}

