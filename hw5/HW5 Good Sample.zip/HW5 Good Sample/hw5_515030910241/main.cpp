/**********************************************
*author :zhaoshenglong
*number :515030910241
*created on Sunday,April 3rd
***********************************************/


#include <iostream>
#include <vector>
#include "hw5_2_515030910241.h"


/**************************************************
*   This main function is used to test the program
*   1.call constructors to create some instances
*   2.create a Shape pointer pointed to classes created
*   3.use pointer to access member function
**************************************************/

int main()
{
/***************************************
    Create some instances
****************************************/
    Circle circle(3.6);
    Square square(6.7);
    Ball ball(9.9);
    Cylinder cylinder(4.8,12.1);

/**************************************
    create a vector to store the pointer
***************************************/
    std::vector<Shape *>shapes;
    Shape *pointer= &circle;
    shapes.push_back(pointer);
    pointer=&square;
    shapes.push_back(pointer);
    pointer=&ball;
    shapes.push_back(pointer);
    pointer=&cylinder;
    shapes.push_back(pointer);

/**************************************
    access member function used pointer
    getArea getVolume
***************************************/
    for (int i=0;i<int(shapes.size());i++ ){
        shapes[i]->getArea();
        std::cout<<"\t\t";
        shapes[i]->getVolume();
        std::cout<<std::endl;
    }

    return 0;
}
