#ifndef HW5_1_515030910241ZSL_H_INCLUDED
#define HW5_1_515030910241ZSL_H_INCLUDED

#include <iostream>
#include <string>
#include <vector>

/*********************************************************
*   This is a user-defined class
*
*   The class contains some functions
*   read_names(), read_ages(), sort(), print()
**** read_names  :get input as names from user
**** read_ages   :get corresponding ages from user
**** sort        :sort name pairs in lexicographic order
**** print       :print namepairs in vertor order
*
*   notation overloading:
**** <<     :the same function as print
**** ==     :judge whether the two namepairs are equal
**** !=     :opposite function of ==
************************************************************/

class Name_pairs{
    public:
        void read_names();
        void read_ages();
        void sort();
        void print();
        friend bool operator !=(Name_pairs &,Name_pairs&);
        friend bool operator ==(Name_pairs &,Name_pairs&);
        friend std::ostream &operator <<(std::ostream&,Name_pairs&);
    private:
        std::vector <std::string> name;
        std::vector <double> age;

};



#endif // HW5_1_515030910241ZSL_H_INCLUDED
