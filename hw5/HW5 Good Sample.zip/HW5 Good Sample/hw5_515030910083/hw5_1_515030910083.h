#include <iostream>
#include<string>
#include<vector>
using namespace std;

class Name_pairs {
public:
	void read_names(string name_stream);
	void read_ages(double age);
	string return_a_name(int i);  //return a name from vector names
	int return_size();      //return the size of vector names
	double return_an_age(int i);   //return an age from vector ages 
	void print();
	void sort();
	bool operator ==(Name_pairs);
	bool operator !=(Name_pairs);
private:
	vector<string> names;
	vector<double> ages;

};


//definitions of function members

void Name_pairs::read_names(string name_stream) {
	int length = name_stream.length();
	int position = 0;        //position of space
	string name;
	while (true) {
		position = name_stream.find(" ");
		if (position == -1) {
			name = name_stream;
			names.push_back(name);
			break;
		}                     //break if there is no more space
		name = name_stream.substr(0, position);
		names.push_back(name);
		name_stream.erase(0, position + 1);    //delete the name which was add to the vector names
	}
}

void Name_pairs::read_ages(double age) {  //add an age to vector ages
	ages.push_back(age);
}

string Name_pairs::return_a_name(int i) {
	return names[i];
}

double Name_pairs::return_an_age(int i) {
	return ages[i];
}

int Name_pairs::return_size() {
	return size(names);
}

void Name_pairs::print() {
	for (int i = 0; i < size(names); i++) {
		cout << "(" << names[i] << "," << ages[i] << ")" << endl;
	}
}

void Name_pairs::sort() {
	int size = return_size();
	string temp_name;   //store a temporary name
	double temp_age;    //store a temporary age
	for (int i = 0; i < size - 1; i++) {  //ð������
		for (int j = i; j < size - 1; j++) {
			string name1 = names[j];
			string name2 = names[j + 1];
			int length = (name1.length() <= name2.length() ? name1.length() : name2.length()); //select the smaller length as the length
			bool bigger = false;
			for (int k = 0; k < length + 1; k++) {        //compare every letter
				if (k == length) {
					if (name1.length() > name2.length()) bigger = true;
					break;
				}
				if (name1[k] > name2[k]) {
					bigger = true;
					break;
				}
			}

			if (bigger) {   //exchange the position in names and in ages if name1 >name2
				temp_name = name1;
				names[j] = names[j + 1];
				names[j + 1] = temp_name;
				temp_age = ages[j];
				ages[j] = ages[j + 1];
				ages[j + 1] = temp_age;
			}
			else continue;
		}
	}
}

ostream&operator<<(ostream&os, Name_pairs&pairs) {       //����<<
	for (int i = 0; i < pairs.return_size(); i++)
		os << "(" << pairs.return_a_name(i) << "," << pairs.return_an_age(i) << ")" << endl;
	return os;
}


bool Name_pairs::operator ==(Name_pairs p2) {               //����==
	if (size(names) != p2.return_size()) return false;      
	for (int i = 0; i < size(names); i++) {              //����names ���������names�������namep2�ж��У��Ҷ�Ӧ��age�ȣ���return true
		string name = names[i];
		bool init = false;           //name�Ƿ���p2��names��
		for (int j = 0; j < p2.return_size(); j++){
			if (name == p2.return_a_name(j)) init = true;
		    if (init) {
				if (names[i] != p2.return_a_name(j)) return false;
			}	
		}
		if (!init) return false;
	}
	return true;
}

 bool Name_pairs::operator !=(Name_pairs p2) {         //��==һ����ture false����
	 if (size(names) != p2.return_size()) return true;
	 for (int i = 0; i < size(names); i++) {
		 string name = names[i];
		 bool init = false;
		 for (int j = 0; j < p2.return_size(); j++) {
			 if (name == p2.return_a_name(j)) init = true;
			 if (init) {
				 if (names[i] != p2.return_a_name(j)) return true;
			 }
		 }
		 if (!init) return true;
	 }
	 return false;
 }



