#include <iostream>
#include<vector>
#define Pi 3.1415926   //define the value of pi
using namespace std;

class Shape {
public:
	virtual void print() const =0;      //pure virtual function print
};

class TwoDimensionalShape :public Shape {
public:
	virtual double getArea() const= 0;   //pure virtual function get_area
	void print() const{                 //define print of TwoDimensionalShape
		cout << "area: " << getArea() << endl;
	}
};

class ThreeDimensionalShape :public Shape {
public:
	virtual double getArea() const = 0;
	virtual double getVolume() const = 0;
	void print() const{                  //define print of ThreeDimensionalShape
		cout << "area: " << getArea() << "   volume: " << getVolume() << endl;
	}
};

class Circle :public TwoDimensionalShape {
public:
	Circle(double rr) :r(rr) {}   //initialize
	double getArea() const {       //define Circle's getArea
		return Pi*r*r;
	}
private:
	double r;
};

class Square :public TwoDimensionalShape {
public:
	Square(double aa):a(aa){}
	double getArea() const {        //define Square's getArea
		return a*a;
	}
private:
	double a;
};

class Ball :public ThreeDimensionalShape {
public:
	Ball(double rr):r(rr){}
	double getArea() const {             //define ball's getArea
		return 4 * Pi*r*r;
	}
	double getVolume() const {         //define ball's getVolume
		return (4/3)*Pi*r*r*r;
	}
private:
	double r;
};

class Cylinder :public ThreeDimensionalShape {
public:
	Cylinder (double rr,double hh):r(rr),h(hh){}
	double getArea() const {                //define Cylinder's getArea
		return 2 * Pi*r*r + 2 * Pi*r*h;
	}
	double getVolume() const {           //define cylinder's getVolume
		return Pi*r*r*h;
	}
private:
	double r;
	double h;
};



int main(){                                //the test function
	Circle circle(5.0);
	Square square(5.0);
	Ball ball(5.0);
	Cylinder cylinder(5.0, 5.0);
	
	vector<Shape*> shapes;
	shapes.push_back(&circle);
	shapes.push_back(&square);
	shapes.push_back(&ball);
	shapes.push_back(&cylinder);
	
	for (int i = 0; i < 4; i++)
		shapes[i]->print();
	
}
